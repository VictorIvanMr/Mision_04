# Mision_04

## Selección

Consulta el documento anexo **Mision_04.pdf** para ver los detalles.

1. Clona el proyecto desde Github.
2. Crea un proyecto especial en Pycharm.
3. Agrega a tu proyecto cada uno de los programas solicitados. **NOMBRA TUS PROGRAMAS COMO LO INDICA EL DOCUMENTO.**
4. Sube a Github cada programa terminado.
5. Desde la página de Github, abre un Pull Request para que te califique. (Escribe tus datos completos en el Pull request para tener derecho a ganar XP o monedas)

Si cumples esta misión, podrás ganar hasta **1250 HP**.

Si eres uno de los **primeros 5 alumnos** que completen esta misión, obtendrás **100 XP**.

Si resuelves los ejercicios extra marcados dentro del documento, puedes ganar hasta **400 XP**.

**¡Los XP ahora son acumulables!** y los podrías usar en el examen teórico final.
***
